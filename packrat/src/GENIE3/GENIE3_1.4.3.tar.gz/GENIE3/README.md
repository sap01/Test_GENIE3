# GENIE3
GENIE3 (GEne Network Inference with Ensemble of trees): Inference of gene regulatory networks from gene expression data

GENIE3 is now available from [Bioconductor](https://bioconductor.org/packages/devel/bioc/html/GENIE3.html). A **tutorial** [(vignette)](https://bioconductor.org/packages/release/bioc/vignettes/GENIE3/inst/doc/GENIE3.html) is included in the package.
